========================================
Nadger
========================================
Version : 0.4b
Author : Daniel "Trebz" Nolan
Homesite : http://apps.sepulchre.co.uk/nadger/
Contact : nadger@sepulchre.co.uk
Copyright 2001 (c) to Daniel "Trebz" Nolan


========================================
Installation
========================================
Copy Nadger.exe into a directory and run it, easy! :-) To leave it running in your taskbar just minimise the application.


========================================
Version History
========================================

0.4b ------------------------------------
Created the colour store, not fully tested yet

0.3 ------------------------------------
Colour Picker Zoom
Hex Input box now accepts typed in values


0.2 ------------------------------------
Colour Utils :
	Negative
	Greyscale
Web Safe info
Scroll Locks

0.1 ------------------------------------
Colour Picker
Minimise to systray
Colour Dialog


========================================
Disclaimer 
========================================
This application was developed in my spare time to help me learn Delphi. By using this application you understand that it may fubar your system, eat your cat and steal all your pizza. If it does, it was of course not intentional and therefore don't blame me. Of course pizza donations will not be turned down.