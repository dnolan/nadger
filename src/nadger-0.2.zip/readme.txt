========================================
Nadger
========================================
Version : 0.2
Author : Daniel "Trebz" Nolan
Homesite : http://apps.sepulchre.co.uk/nadger/
Contact : nadger@sepulchre.co.uk


========================================
Installation
========================================
Copy Nadger.exe into a directory and run it, easy! :-) To leave it running in your taskbar just minimise the application.



========================================
Version History
========================================

0.2 ------------------------------------
Colour Utils :
	Negative
	Greyscale
Web Safe info
Scroll Locks

0.1 ------------------------------------
Colour Picker
Minimise to systray
Colour Dialog


========================================
Nadger is Copyright 2001 (c) to Daniel "Trebz" Nolan
========================================